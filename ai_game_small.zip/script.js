let low = 1;
let high = 100;
let guess = 50;

function updateGuess() {
  guess = Math.floor((low + high) / 2);
  document.getElementById("guess").innerText = "AI Guess: " + guess;
}

function tooLow() {
  low = guess + 1;
  updateGuess();
}

function tooHigh() {
  high = guess - 1;
  updateGuess();
}

function correct() {
  document.getElementById("result").innerText = "🎉 AI guessed correctly!";
}
